var GLOBAL = {};
